const STORAGE_KEY="civilMediaNews", SETTINGS_KEY="civilMediaSettings", GALLERY_KEY="civilMediaGallery", SUBSCRIBERS_KEY="civilMediaSubscribers", CONTACT_KEY="civilMediaContacts", AUTH_KEY="civilMediaAdmin";
const fallbackImage="https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=1200&q=80";
const categories=["Nepal","Politics","Business","International","Entertainment","Sports","Technology"];

const demoNews=[
{id:"1",title:"The Civil Media launches its new digital news platform",titleNp:"द सिभिल मिडियाले नयाँ डिजिटल समाचार प्लेटफर्म सुरु गर्‍यो",category:"Nepal",author:"The Civil Media Desk",image:fallbackImage,excerpt:"The Civil Media Private Limited introduces a modern digital platform for news and public information.",excerptNp:"द सिभिल मिडिया प्रा.लि. ले समाचार र सार्वजनिक सूचनाका लागि आधुनिक डिजिटल प्लेटफर्म सुरु गरेको छ।",content:"The Civil Media Private Limited has launched its digital news portal with dedicated coverage of Nepal, politics, business, international affairs, sports, entertainment and technology.",contentNp:"द सिभिल मिडिया प्रा.लि. ले नेपाल, राजनीति, व्यवसाय, अन्तर्राष्ट्रिय मामिला, खेलकुद, मनोरञ्जन र प्रविधिको समेटिएको डिजिटल समाचार पोर्टल सुरु गरेको छ।",status:"published",archived:false,featured:true,breaking:true,createdAt:"2026-09-20T06:00:00"},
{id:"2",title:"Nepal's digital media landscape continues to evolve",titleNp:"नेपालको डिजिटल मिडिया क्षेत्र निरन्तर परिवर्तन हुँदै",category:"Nepal",author:"News Desk",image:"https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?auto=format&fit=crop&w=900&q=80",excerpt:"Digital platforms are becoming an important channel for news and public information.",excerptNp:"डिजिटल प्लेटफर्म समाचार र सार्वजनिक सूचनाको महत्वपूर्ण माध्यम बन्दै गएका छन्।",content:"Digital media is changing how audiences discover, read and share news across Nepal.",contentNp:"डिजिटल मिडियाले नेपालमा समाचार खोज्ने, पढ्ने र साझा गर्ने तरिका परिवर्तन गरिरहेको छ।",status:"published",archived:false,featured:false,breaking:false,createdAt:"2026-09-19T10:00:00"},
{id:"3",title:"Business community focuses on innovation and growth",titleNp:"व्यवसायिक क्षेत्र नवप्रवर्तन र वृद्धिमा केन्द्रित",category:"Business",author:"Business Desk",image:"https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=900&q=80",excerpt:"Businesses are exploring technology, investment and new market opportunities.",excerptNp:"व्यवसायहरूले प्रविधि, लगानी र नयाँ बजार अवसर खोजिरहेका छन्।",content:"The business community continues to focus on innovation, digital transformation and sustainable growth.",contentNp:"व्यवसायिक क्षेत्र नवप्रवर्तन, डिजिटल रूपान्तरण र दिगो वृद्धिमा केन्द्रित छ।",status:"published",archived:false,featured:false,breaking:false,createdAt:"2026-09-18T14:00:00"},
{id:"4",title:"Technology is reshaping everyday communication",titleNp:"प्रविधिले दैनिक सञ्चारलाई नयाँ रूप दिँदै",category:"Technology",author:"Tech Desk",image:"https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80",excerpt:"New digital tools continue to influence how people work, learn and communicate.",excerptNp:"नयाँ डिजिटल उपकरणहरूले काम, सिकाइ र सञ्चारको तरिकामा प्रभाव पारिरहेका छन्।",content:"Technology remains one of the fastest-changing areas of modern society, creating new tools and services.",contentNp:"प्रविधि आधुनिक समाजको तीव्र परिवर्तन हुने क्षेत्रमध्ये एक हो, जसले नयाँ उपकरण र सेवाहरू सिर्जना गरिरहेको छ।",status:"published",archived:false,featured:false,breaking:false,createdAt:"2026-09-17T11:00:00"},
{id:"5",title:"Sports events bring communities together",titleNp:"खेलकुद प्रतियोगिताले समुदायलाई जोड्दै",category:"Sports",author:"Sports Desk",image:"https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=900&q=80",excerpt:"Local and international sporting events continue to attract audiences.",excerptNp:"स्थानीय तथा अन्तर्राष्ट्रिय खेलकुद प्रतियोगिताले दर्शकको ध्यान आकर्षित गरिरहेका छन्।",content:"Sports coverage remains an important part of the daily news cycle, with competitions taking place around the world.",contentNp:"विश्वभर भइरहेका खेलकुद प्रतियोगिताका कारण खेल समाचार दैनिक समाचार चक्रको महत्वपूर्ण भाग बनेको छ।",status:"published",archived:false,featured:false,breaking:false,createdAt:"2026-09-16T15:30:00"},
{id:"6",title:"Global developments remain in focus",titleNp:"विश्वका महत्वपूर्ण घटनाक्रममा ध्यान केन्द्रित",category:"International",author:"International Desk",image:"https://images.unsplash.com/photo-1521295121783-8a321d551ad2?auto=format&fit=crop&w=900&q=80",excerpt:"Major international developments are being followed by audiences around the world.",excerptNp:"विश्वभरका दर्शकले महत्वपूर्ण अन्तर्राष्ट्रिय घटनाक्रमलाई नजिकबाट नियालिरहेका छन्।",content:"International news continues to shape discussions across regions and communities.",contentNp:"अन्तर्राष्ट्रिय समाचारले विभिन्न क्षेत्र र समुदायमा बहसलाई प्रभावित गरिरहेको छ।",status:"published",archived:false,featured:false,breaking:true,createdAt:"2026-09-15T09:30:00"}
];

const defaultSettings={
companyName:"The Civil Media Private Limited",companyNameNp:"द सिभिल मिडिया प्रा.लि.",
address:"Bhaktapur, Nepal",email:"info@thecivilmedia.com",phone:"+977-XXXXXXXXXX",
about:"The Civil Media Private Limited is a news platform based in Bhaktapur, Nepal. We publish news and public information across Nepal, politics, business, international affairs, entertainment, sports and technology.",
aboutNp:"द सिभिल मिडिया प्रा.लि. भक्तपुर, नेपालमा आधारित समाचार प्लेटफर्म हो। हामी नेपाल, राजनीति, व्यवसाय, अन्तर्राष्ट्रिय मामिला, मनोरञ्जन, खेलकुद र प्रविधिसम्बन्धी समाचार तथा सार्वजनिक सूचना प्रकाशित गर्छौं।",
logoUrl:"assets/images/logo.jpeg",defaultImage:fallbackImage,heroImage:"",fontFamily:"Inter",headingFont:"Playfair Display",primaryColor:"#102d8d",accentColor:"#d71920",backgroundColor:"#f7f8fa",cardRadius:12,containerWidth:1180,
showAds:true,adTop:"Advertisement • 728 × 90",adSide:"Advertisement • 300 × 250",facebook:"",youtube:"",instagram:"",x:"",tiktok:"",language:"en"
};

function getNews(){try{const s=localStorage.getItem(STORAGE_KEY);if(!s){localStorage.setItem(STORAGE_KEY,JSON.stringify(demoNews));return demoNews}return JSON.parse(s)}catch{return demoNews}}
function saveNews(x){localStorage.setItem(STORAGE_KEY,JSON.stringify(x))}
function getSettings(){try{return {...defaultSettings,...(JSON.parse(localStorage.getItem(SETTINGS_KEY)||"{}"))}}catch{return defaultSettings}}
function saveSettings(x){localStorage.setItem(SETTINGS_KEY,JSON.stringify({...defaultSettings,...x}))}
function getGallery(){try{return JSON.parse(localStorage.getItem(GALLERY_KEY)||"[]")}catch{return[]}}
function saveGallery(x){localStorage.setItem(GALLERY_KEY,JSON.stringify(x))}
function getAuth(){try{return JSON.parse(localStorage.getItem(AUTH_KEY)||'{"username":"admin","password":"admin123"}')}catch{return{username:"admin",password:"admin123"}}}
function saveAuth(x){localStorage.setItem(AUTH_KEY,JSON.stringify(x))}
function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function imageOrFallback(u){return u&&u.trim()?u:getSettings().defaultImage||fallbackImage}
function formatDateTime(v){return new Date(v).toLocaleString("en-US",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}
function currentLang(){return localStorage.getItem("civilMediaLang")||getSettings().language||"en"}
function txt(en,np){return currentLang()==="np"?(np||en):en}

function applyTheme(){
 const s=getSettings(), root=document.documentElement;
 root.style.setProperty("--navy",s.primaryColor);root.style.setProperty("--red",s.accentColor);root.style.setProperty("--bg",s.backgroundColor);
 root.style.setProperty("--radius",(Number(s.cardRadius)||12)+"px");root.style.setProperty("--container-width",(Number(s.containerWidth)||1180)+"px");
 document.body.style.fontFamily=s.fontFamily+", Arial, sans-serif";
 const h=document.querySelectorAll("h1,h2,h3,.brand-name,.article-content");h.forEach(e=>{if(!e.closest("style"))e.style.fontFamily=s.headingFont+", Georgia, serif"});
}
function headerTemplate(){
 const s=getSettings();
 const nav=[["Home","index.html"],["Nepal","index.html?category=Nepal"],["Politics","index.html?category=Politics"],["Business","index.html?category=Business"],["International","index.html?category=International"],["Entertainment","index.html?category=Entertainment"],["Sports","index.html?category=Sports"],["Technology","index.html?category=Technology"],["Gallery","gallery.html"],["About","about.html"],["Contact","contact.html"]];
 return `<div class="top-strip"><div class="container top-strip-inner"><span id="currentDate"></span><span>${esc(s.address)}</span></div></div>
 <header class="site-header"><div class="container header-main"><a class="brand" href="index.html"><img src="${esc(s.logoUrl)}" onerror="this.src='assets/images/logo.jpeg'" alt="${esc(s.companyName)}"><div><div class="brand-name">${esc(currentLang()==="np"?s.companyNameNp:s.companyName)}</div><div class="brand-subtitle">PRIVATE LIMITED</div></div></a><div class="header-actions"><button class="icon-btn" id="searchToggle" aria-label="Search">⌕</button><button class="lang-btn" id="langToggle">${currentLang()==="np"?"EN":"नेपाली"}</button><a class="admin-link" href="admin/login.html">Admin</a></div></div>
 <nav class="main-nav"><div class="container nav-inner"><button class="mobile-menu-btn" id="mobileMenuBtn">☰ Menu</button><div class="nav-links" id="navLinks">${nav.map(([n,u])=>`<a href="${u}">${currentLang()==="np"&&n==="Home"?"गृह":n}</a>`).join("")}</div></div></nav></header>
 <section class="breaking-bar"><div class="container breaking-inner"><span class="breaking-label">${currentLang()==="np"?"ब्रेकिङ":"BREAKING"}</span><div class="ticker-window"><div id="breakingTicker" class="ticker-track"></div></div></div></section>
 <section class="ad-wrap container ${s.showAds?"":"hidden"}"><div class="ad-slot">${esc(s.adTop)}</div></section>`;
}
function footerTemplate(){
 const s=getSettings();
 return `<footer class="site-footer"><div class="container footer-grid"><div><img class="footer-logo" src="${esc(s.logoUrl)}" onerror="this.src='assets/images/logo.jpeg'" alt="Logo"><p>${esc(txt(s.about,s.aboutNp))}</p></div><div><h3>Categories</h3>${categories.slice(0,4).map(c=>`<a href="index.html?category=${encodeURIComponent(c)}">${esc(c)}</a>`).join("")}</div><div><h3>More</h3><a href="gallery.html">Video / Photo Gallery</a><a href="about.html">About</a><a href="contact.html">Contact</a><a href="admin/login.html">Admin</a></div><div><h3>Contact</h3><p>${esc(s.address)}</p><p>${esc(s.email)}</p><p>${esc(s.phone)}</p><div class="socials">${[["facebook","f"],["youtube","▶"],["instagram","◎"],["x","𝕏"],["tiktok","♪"]].filter(x=>s[x[0]]).map(x=>`<a href="${esc(s[x[0]])}" target="_blank" rel="noopener">${x[1]}</a>`).join("")}</div></div></div><div class="footer-bottom"><div class="container">© ${new Date().getFullYear()} ${esc(s.companyName)}. All rights reserved.</div></div></footer>`;
}
function setupShell(){
 const h=document.getElementById("siteHeader"),f=document.getElementById("siteFooter");
 if(h)h.innerHTML=headerTemplate();if(f)f.innerHTML=footerTemplate();
 applyTheme();
 const d=new Date(),date=document.getElementById("currentDate");if(date)date.textContent=d.toLocaleDateString(currentLang()==="np"?"ne-NP":"en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
 document.getElementById("mobileMenuBtn")?.addEventListener("click",()=>document.getElementById("navLinks")?.classList.toggle("open"));
 document.getElementById("langToggle")?.addEventListener("click",()=>{localStorage.setItem("civilMediaLang",currentLang()==="np"?"en":"np");location.reload()});
 document.getElementById("searchToggle")?.addEventListener("click",()=>{const p=document.getElementById("searchPanel");if(p){p.classList.toggle("hidden");document.getElementById("searchInput")?.focus()}else location.href="index.html#search"});
}
function card(n){
 const title=txt(n.title,n.titleNp),excerpt=txt(n.excerpt,n.excerptNp);
 return `<article class="news-card"><a href="article.html?id=${encodeURIComponent(n.id)}"><img src="${esc(imageOrFallback(n.image))}" onerror="this.src='${fallbackImage}'" alt="${esc(title)}"></a><div class="news-card-body"><span class="category-label">${esc(n.category)}</span><a href="article.html?id=${encodeURIComponent(n.id)}"><h3>${esc(title)}</h3></a><p class="excerpt">${esc(excerpt)}</p><div class="meta">${formatDateTime(n.createdAt)} · ${esc(n.author||"The Civil Media")}</div></div></article>`;
}
function renderHome(){
 setupShell();
 const all=getNews().filter(n=>n.status==="published"&&!n.archived).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
 const p=new URLSearchParams(location.search),cat=p.get("category"),q=p.get("q");
 const hero=document.getElementById("heroSection"),latest=document.getElementById("latestNews"),no=document.getElementById("noResults");
 if(cat||q){
  const filtered=all.filter(n=>(!cat||n.category.toLowerCase()===cat.toLowerCase())&&(!q||`${n.title} ${n.titleNp} ${n.excerpt} ${n.excerptNp} ${n.content} ${n.contentNp} ${n.category}`.toLowerCase().includes(q.toLowerCase())));
  hero.innerHTML=`<div class="page-banner" style="grid-column:1/-1"><span class="eyebrow">NEWS</span><h1>${esc(cat||"Search Results")}</h1><p>${q?`Results for “${esc(q)}”`:`Latest ${esc(cat)} stories`}</p></div>`;
  latest.innerHTML=filtered.map(card).join("");no.classList.toggle("hidden",filtered.length>0);document.querySelectorAll(".category-section,.newsletter").forEach(e=>e.classList.add("hidden"));
 }else{
  document.querySelectorAll(".category-section,.newsletter").forEach(e=>e.classList.remove("hidden"));no.classList.add("hidden");
  const featured=all.find(n=>n.featured)||all[0],side=all.filter(n=>n.id!==featured?.id).slice(0,4);
  hero.innerHTML=featured?`<article class="hero-main"><a href="article.html?id=${featured.id}"><img src="${esc(imageOrFallback(getSettings().heroImage||featured.image))}" onerror="this.src='${fallbackImage}'" alt=""><div class="hero-overlay"><span class="category-label">${esc(featured.category)}</span><h1>${esc(txt(featured.title,featured.titleNp))}</h1><div class="meta light-meta">${formatDateTime(featured.createdAt)} · ${esc(featured.author)}</div></div></a></article><aside class="hero-side"><h3>${txt("Top Stories","शीर्ष समाचार")}</h3>${side.map(n=>`<div class="side-story"><span class="category-label">${esc(n.category)}</span><a href="article.html?id=${n.id}"><div class="story-title">${esc(txt(n.title,n.titleNp))}</div></a><div class="meta">${formatDateTime(n.createdAt)}</div></div>`).join("")}</aside>`:"";
  latest.innerHTML=all.slice(0,6).map(card).join("");
  renderCategory("Nepal","nepalNews",all);renderCategory("Business","businessNews",all);renderCategory("International","internationalNews",all);
  const b=all.filter(n=>n.breaking);document.getElementById("breakingTicker").innerHTML=(b.length?b:all.slice(0,5)).map(n=>`🔴 ${esc(txt(n.title,n.titleNp))}`).join(" &nbsp;&nbsp;&nbsp; ");
 }
 setupSearch();
}
function renderCategory(c,id,all){const t=document.getElementById(id);if(!t)return;const x=all.filter(n=>n.category===c).slice(0,3);t.innerHTML=x.length?x.map(card).join(""):`<div style="grid-column:1/-1;color:var(--muted);padding:20px 0">No published stories in this category yet.</div>`}
function setupSearch(){
 document.getElementById("searchForm")?.addEventListener("submit",e=>{e.preventDefault();const q=document.getElementById("searchInput").value.trim();if(q)location.href=`index.html?q=${encodeURIComponent(q)}`});
 document.getElementById("closeSearch")?.addEventListener("click",()=>document.getElementById("searchPanel")?.classList.add("hidden"));
}
function renderGalleryPage(){
 setupShell();const grid=document.getElementById("galleryGrid"),items=getGallery();
 const draw=(type="all")=>{const x=type==="all"?items:items.filter(i=>i.type===type);grid.innerHTML=x.length?x.map(i=>`<article class="gallery-card"><img src="${esc(i.image)}" onerror="this.src='${fallbackImage}'" alt="${esc(i.title)}"><div><span class="category-label">${esc(i.type)}</span><h3>${esc(txt(i.title,i.titleNp))}</h3>${i.type==="video"&&i.url?`<a class="btn btn-primary btn-small" href="${esc(i.url)}" target="_blank">Watch Video ↗</a>`:""}</div></article>`).join(""):`<div class="content-panel" style="grid-column:1/-1">No gallery items available.</div>`};
 draw();document.querySelectorAll(".gallery-tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".gallery-tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");draw(b.dataset.type)}));
}
function renderAboutPage(){setupShell();const s=getSettings();document.getElementById("aboutContent").innerHTML=`<p class="lead">${esc(txt(s.about,s.aboutNp))}</p><h2>Our Coverage</h2><p>The Civil Media covers Nepal, politics, business, international affairs, entertainment, sports and technology, along with visual stories and public-interest information.</p>`}
function renderContactPage(){
 setupShell();const s=getSettings();document.getElementById("contactInfo").innerHTML=`<p><strong>Address</strong><br>${esc(s.address)}</p><p><strong>Email</strong><br>${esc(s.email)}</p><p><strong>Phone</strong><br>${esc(s.phone)}</p><div class="socials">${[["facebook","Facebook"],["youtube","YouTube"],["instagram","Instagram"],["x","X"],["tiktok","TikTok"]].filter(x=>s[x[0]]).map(x=>`<a href="${esc(s[x[0]])}" target="_blank" rel="noopener">${x[1]}</a>`).join("")}</div>`;
 document.getElementById("contactForm").addEventListener("submit",e=>{e.preventDefault();const x=JSON.parse(localStorage.getItem(CONTACT_KEY)||"[]");x.push({id:Date.now(),name:contactName.value,email:contactEmail.value,subject:contactSubject.value,message:contactMessage.value,createdAt:new Date().toISOString()});localStorage.setItem(CONTACT_KEY,JSON.stringify(x));alert("Thank you. Your message has been saved.");e.target.reset()});
}
window.CivilMedia={renderGalleryPage,renderAboutPage,renderContactPage,getSettings,getNews};
if(document.getElementById("heroSection")) renderHome();
else if(document.getElementById("siteHeader")) setupShell();
